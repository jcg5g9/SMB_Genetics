Please check the meta-data document attached for more information about the spatial data. This document is updated regularly, so always make sure to check on the www.iucnredlist.org website, under 'Resources -> Spatial Data download' for the latest version�

The data contained in this zip file is an ESRI shapefile format, so you will need appropriate GIS software such as ArcGIS or QGIS to be able to view it

For any questions, please contact the IUCN Red List Unit <redlistgis@iucn.org>

